
class LanguageBr{


  static final feedPage_text_promoter_name = "Nome Promoter";
  static final feedPage_text_promoter_local = "Cidade - SP";
  static final feedPage_text_event_name = "Nome do evento";

  static final profilePage_text_full_name = "Nome Sobrenome";
  static final profilePage_text_local = "Local Atual";
  static final profilePage_text_event_name = "Nome do evento";
  static final profilePage_text_event_local = "Local do evento";
  static final profilePage_text_event_date = "Data do evento";
}